# Kino Bot — Railway Deploy

## Deploy qilish (Railway.app — BEPUL)

1. https://railway.app ga kiring (GitHub bilan)
2. "New Project" → "Deploy from GitHub repo"
3. Repo yarating va bu fayllarni yuklang
4. "Variables" bo'limida qo'shing:
   - `BOT_TOKEN` = sizning bot tokeningiz
5. Deploy tugmasini bosing ✅

## Fayllar
- `kinonew.py` — asosiy bot
- `requirements.txt` — kutubxonalar
- `Procfile` — Railway uchun ishga tushirish buyrug'i
- `.env.example` — muhit o'zgaruvchilari namunasi

## Muhim
- `cinema.db` fayli avtomatik yaratiladi
- Bot 24/7 ishlaydi
